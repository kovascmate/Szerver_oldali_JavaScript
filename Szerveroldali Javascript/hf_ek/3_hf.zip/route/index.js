const renderMW = require('../middleware/renderMW');
const delTeammateMW = require('../middleware/teammate/delTeammateMW');
const getTeammateskMW = require('../middleware/teammate/getTeammateskMW');
const getTeammateMW = require('../middleware/teammate/getTeammateMW');
const saveTeammateMW = require('../middleware/teammate/saveTeammateMW');
const delTeamMW = require('../middleware/team/delTeamMW');
const getTeamsMW = require('../middleware/team/getTeamsMW');
const getTeamMW = require('../middleware/team/getTeamMW');
const saveTeamMW = require('../middleware/team/saveTeamMW');

module.exports = function (app) {
    const objRepo = {};
    app.use('/',
        renderMW(objRepo, 'index')),
    app.get('/team',
        getTeamsMW(objRepo),
        renderMW(objRepo, 'teamlist'));
    app.use('/team/new',
        saveTeamMW(objRepo),
        renderMW(objRepo, 'teameditnew'));
    app.use('/team/edit/:teamid',
        getTeamMW(objRepo),
        saveTeamMW(objRepo),
        renderMW(objRepo, 'teameditnew'));
    app.get('/team/del/:teamid',
        getTeamMW(objRepo),
        delTeamMW(objRepo)),
    app.get('/teammate/:teamid',
        getTeamMW(objRepo),
        getTeammateekMW(objRepo),
        renderMW(objRepo, 'egyteamteammatejei'));
    app.use('/teammate/:teamid/new',
        getTeamMW(objRepo),
        saveTeammateMW(objRepo),
        renderMW(objRepo, 'teammateeditnew'));
    app.use('/teammate/:teamid/edit/:teammateid',
        getTeamMW(objRepo),
        getTeammateMW(objRepo),
        saveTeammateMW(objRepo),
        renderMW(objRepo, 'teammateeditnew'));
    app.get('/teammate/:teamid/del/:teammateid',
        getTeamMW(objRepo),
        getTeammateMW(objRepo),
        delTeammateMW(objRepo),
        renderMW(objRepo, 'teammateeditnew'));
};
