/**
 * Load a teammate from the database using the :teammateid param
 * The result is saved to res.locals.team.teammates
 */
const requireOption = require('../requireOption');

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};
