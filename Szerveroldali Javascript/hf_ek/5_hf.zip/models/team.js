var Schema = require('mongoose').Schema;
var db = require('../config/db');


var Team = db.model('Team', {
  name: String,
  size: Int32Array,
  Founder: String,
});

module.exports = Team;