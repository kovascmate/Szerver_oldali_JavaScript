var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/ib72d1');

module.exports = mongoose;